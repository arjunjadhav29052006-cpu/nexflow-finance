# Nexflow Financial OS

Personal financial discipline system for Nexflow Automations — built for annual billing, pre-revenue B2B SaaS.

## What it does

- **Log payments** as they arrive (annual contracts + setup fees)
- **Auto-allocates** every rupee into 6 disciplined buckets on receipt
- **Tracks cumulative bucket totals** across all clients
- **Verdicts** based on client count and ARR stage
- **Hard rules** hardcoded — no exceptions, no rationalising
- **Growth phase tracker** from proof-of-concept to ₹925Cr exit

## Bucket allocation

| Bucket | % | Rule |
|---|---|---|
| Tax Reserve | 25% | Separate account, day of payment. Non-negotiable. |
| Infra & Ops | 12% | Supabase Pro + Vercel + Claude Code autopay. |
| Emergency Fund | 10% | Frozen at ₹50,000. Redirects to reinvestment after cap. |
| Reinvestment | 28% | CA referral fee, one-pager, demo. Pre-decided spend only. |
| Client Service Reserve | 10% | Surprise requests, onboarding, bug fixes. |
| Personal / Director Salary | 15% | Extract as director remuneration. Scales at 5 and 10 clients. |

**Setup fees go entirely to reinvestment — not split.**

## Stack

- Vanilla HTML + CSS + JS
- Zero dependencies
- localStorage persistence
- Deploy anywhere: GitHub Pages, Vercel, Netlify

## Deploy to GitHub Pages

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/nexflow-finance.git
git push -u origin main
```

Then enable GitHub Pages in repo Settings → Pages → Source: `main` branch.

## Local

Just open `index.html` in a browser. No build step required.

---

*This is a private financial tool. Do not share your deployment URL publicly.*
